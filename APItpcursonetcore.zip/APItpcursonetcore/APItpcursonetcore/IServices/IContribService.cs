﻿using Entities.Items;
using Entities.RequestModels;

namespace APItpcursonetcore.IServices
{
    public interface IContribService
    {
        int RegisterNewContrib(NewContribRequest newContribRequest);
        List<ContribItem> GetAllContrib();
    }
}
