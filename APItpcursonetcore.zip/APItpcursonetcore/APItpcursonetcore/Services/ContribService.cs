﻿using APItpcursonetcore.IServices;
using Entities.Items;
using Entities.RequestModels;
using Logic.ILogic;

namespace APItpcursonetcore.Services
{
    public class ContribService : IContribService
    {
        private readonly IContribLogic _contribLogic;
        public ContribService(IContribLogic contribLogic) 
        {
            _contribLogic = contribLogic;
        }
        public List<ContribItem> GetAllContrib()
        {
            return _contribLogic.GetAllContribs();
        }
        public int RegisterNewContrib(NewContribRequest newContribRequest) 
        {
            var newContrib = newContribRequest.ToContribItem();
            return _contribLogic.InsertContrib(newContrib);
        }
    }
}
