﻿using APItpcursonetcore.IServices;
using Entities.Items;
using Entities.RequestModels;
using Microsoft.AspNetCore.Mvc;

namespace APItpcursonetcore.Controllers
{
    [ApiController]
    [Route("[controller]/[Action]")]
    public class ContribController : ControllerBase
    {
        private readonly IContribService _contribService;
        public ContribController(IContribService contribService) {
            _contribService = contribService;
        }
        [HttpPost(Name = "InsertContrib")]
        public int InsertContrib(NewContribRequest newContribRequest)
        {
            return _contribService.RegisterNewContrib(newContribRequest);
        }
        [HttpGet(Name = "GetAllContrib")]
        public List<ContribItem> GetAllContrib()
        {
            return _contribService.GetAllContrib();
        }
    }
}
