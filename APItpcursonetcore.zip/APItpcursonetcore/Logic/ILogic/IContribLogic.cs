﻿using Entities.Items;

namespace Logic.ILogic
{
    public interface IContribLogic
    {
        int InsertContrib(ContribItem contribIterm);
        List<ContribItem> GetAllContribs();
    }
}
