﻿using Data;
using Entities.Items;
using Logic.ILogic;

namespace Logic.Logic
{
    public class ContribLogic : IContribLogic
    {
        private readonly ServiceContext _tpcursonetcoreContext;
        public ContribLogic(ServiceContext tpcursonetcoreContext)
        {
            _tpcursonetcoreContext = tpcursonetcoreContext;
        }
        public List<ContribItem> GetAllContribs()
        {
            return _tpcursonetcoreContext.Contribs.ToList();
        }

        public int InsertContrib(ContribItem contribItem)
        {
            _tpcursonetcoreContext.Contribs.Add(contribItem);
            _tpcursonetcoreContext.SaveChanges();
            return contribItem.Id;
        }
    }
}
