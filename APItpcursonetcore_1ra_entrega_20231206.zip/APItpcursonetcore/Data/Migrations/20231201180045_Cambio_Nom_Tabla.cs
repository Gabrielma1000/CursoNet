﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Data.Migrations
{
    /// <inheritdoc />
    public partial class CambioNomTabla : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_T_Contrib",
                table: "T_Contrib");

            migrationBuilder.RenameTable(
                name: "T_Contrib",
                newName: "T_CONTRIB");

            migrationBuilder.AddPrimaryKey(
                name: "PK_T_CONTRIB",
                table: "T_CONTRIB",
                column: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_T_CONTRIB",
                table: "T_CONTRIB");

            migrationBuilder.RenameTable(
                name: "T_CONTRIB",
                newName: "T_Contrib");

            migrationBuilder.AddPrimaryKey(
                name: "PK_T_Contrib",
                table: "T_Contrib",
                column: "Id");
        }
    }
}
