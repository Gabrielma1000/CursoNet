﻿using Entities.Items;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Oracle.EntityFrameworkCore;

namespace Data.ModelConfigurations
{
    public class ContribTableConfig : IEntityTypeConfiguration<ContribItem>
    {
        public void Configure(EntityTypeBuilder<ContribItem> e)
        {
            e.ToTable("T_CONTRIB");
            //e.Property(e => e.Id).ValueGeneratedNever();
        }
    }
}