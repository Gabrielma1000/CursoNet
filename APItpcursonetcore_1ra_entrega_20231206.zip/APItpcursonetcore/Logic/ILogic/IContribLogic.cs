﻿using Entities.Items;

namespace Logic.ILogic
{
    public interface IContribLogic
    {
        int InsertContrib(ContribItem contribIterm);
        List<ContribItem> GetAllContribs();
        int UpdateContrib(ContribItem contribIterm);
        int DeleteContrib(ContribItem contribIterm);
    }
}
