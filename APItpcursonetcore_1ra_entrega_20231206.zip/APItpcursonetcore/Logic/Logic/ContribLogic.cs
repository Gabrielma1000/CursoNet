﻿using Data;
using Entities.Items;
using Logic.ILogic;
using Microsoft.EntityFrameworkCore;

namespace Logic.Logic
{
    public class ContribLogic : IContribLogic
    {
        private readonly ServiceContext _tpcursonetcoreContext;
        public ContribLogic(ServiceContext tpcursonetcoreContext)
        {
            _tpcursonetcoreContext = tpcursonetcoreContext;
        }
        public List<ContribItem> GetAllContribs()
        {
            return _tpcursonetcoreContext.Contribs.ToList();
        }

        public int InsertContrib(ContribItem contribItem)
        {
            _tpcursonetcoreContext.Contribs.Add(contribItem);
            _tpcursonetcoreContext.SaveChanges();
            return contribItem.Id;
        }
        public int UpdateContrib(ContribItem contribItem)
        {
            _tpcursonetcoreContext.Contribs.Update(contribItem);
            _tpcursonetcoreContext.SaveChanges();
            return contribItem.Id;
        }
        public int DeleteContrib(ContribItem contribItem)
        {
            _tpcursonetcoreContext.Contribs.Remove(contribItem);
            _tpcursonetcoreContext.SaveChanges();
            return contribItem.Id;
        }
    }
}
