﻿using Entities.Items;

namespace Entities.RequestModels
{
    public class NewContribRequest
    {
        public int Cuit { get; set; }
        public string? Nombre { get; set; }
        public string? Apellido { get; set; }
        public ContribItem ToContribItem()
        {
            var contribItem = new ContribItem();
            contribItem.Cuit = Cuit;
            contribItem.Nombre = Nombre;
            contribItem.Apellido = Apellido;
            return contribItem;
        }
    }
    public class UpdContribRequest
    {
        public int Id { get; set; }
        public int Cuit { get; set; }
        public string? Nombre { get; set; }
        public string? Apellido { get; set; }
        public ContribItem ToContribItem()
        {
            var contribItem = new ContribItem();
            contribItem.Id = Id;
            contribItem.Cuit = Cuit;
            contribItem.Nombre = Nombre;
            contribItem.Apellido = Apellido;
            return contribItem;
        }
    }
    public class DelContribRequest
    {
        public int Id { get; set; }
        public ContribItem ToContribItem()
        {
            var contribItem = new ContribItem();
            contribItem.Id = Id;
            return contribItem;
        }
    }
}
