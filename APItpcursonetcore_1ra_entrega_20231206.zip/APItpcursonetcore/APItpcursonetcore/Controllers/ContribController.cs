﻿using APItpcursonetcore.IServices;
using Entities.Items;
using Entities.RequestModels;
using Microsoft.AspNetCore.Mvc;

namespace APItpcursonetcore.Controllers
{
    [ApiController]
    [Route("[controller]/[Action]")]
    public class ContribController : ControllerBase
    {
        private readonly IContribService _contribService;
        public ContribController(IContribService contribService) {
            _contribService = contribService;
        }
        [HttpPost(Name = "InsertContrib")]
        public int InsertContrib(NewContribRequest newContribRequest)
        {
            return _contribService.RegisterNewContrib(newContribRequest);
        }
        [HttpPost(Name = "UpdateContrib")]
        public int UpdateContrib(UpdContribRequest updContribRequest)
        {
            return _contribService.RegisterUpdContrib(updContribRequest);
        }
        [HttpPost(Name = "DeleteContrib")]
        public int DeleteContrib(DelContribRequest delContribRequest)
        {
            return _contribService.RegisterDelContrib(delContribRequest);
        }
        [HttpGet(Name = "GetAllContrib")]
        public List<ContribItem> GetAllContrib()
        {
            return _contribService.GetAllContrib();
        }
    }
}
